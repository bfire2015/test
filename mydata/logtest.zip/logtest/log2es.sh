#!/bin/bash

WORKDIR=$(cd `dirname $0`;pwd)
cd $WORKDIR

while(true)
do
  sleep 10
  php /data/to8to/tools/log2es/ApplogCommand.php  >> $WORKDIR/log/crontab_run.log
done


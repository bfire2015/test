<?php
/**
 * **************************************************************************************
 * Description   : 自动化执行 命令行模式 monolog\Thriftlog\Phplog\Accesslog 导入到 ES
 *                 于2015年4月15日新增加 php-fpm 与 nginx 错误日志
 * Filename      : ApplogCommand.php
 * Create time   : 2015-03-23
 * Last modified : 2015-06-11 
 * License       : MIT, GPL
 * update        : bfire
 * $getNum       :第个文件读取行数 844行
 * **************************************************************************************
 */
 
 
class ApplogCommand 
{
	 /**
     * @var _index
     */
    protected $_index = '';

    /**
     * @var _type
     */
    protected $_type  = '';
	
	    /**
     * @var _root
     */
	protected $_root  = '';
	
	/**
     * @var _logdir
     */
	protected $_logdir  = array();
	
     /**
     * @var _logdir
     */
	protected $_logflag  = 0;
	
	
    public function run() {


    	//设置响应时间不限制 
		@set_time_limit(0);
		//设置最大缓存块是512M 
		@ini_set('memory_limit','512M'); 


		//网站根目录
		if (!defined('ROOT')) {                       
			define('ROOT', dirname(__FILE__));
			//目前root 只显示到 D:\wamp\www\tboss\protected
		}

	  //所要执行的任务，如数据符合某条件更新，删除，修改
       $txt = '===================== all the start ========'.date("Y-m-d h:i:sa", time()).'================= ';
        //日志操作
	   $this->rewritetolog('allthestart', $txt);

        //导入ES 核心包
	    require_once(ROOT.'/ElasticaAutoLoader.php');
        spl_autoload_register(array('ElasticaAutoLoader','loadClass'));

	      //导入 ES 配置
         $All_config = require_once(ROOT.'/config.php');
		 
         //库与表
         $index  = $All_config['params']['ES_conn']['_index']?$All_config['params']['ES_conn']['_index']:'applog';
         $type   = $All_config['params']['ES_conn']['_type']?$All_config['params']['ES_conn']['_type']:'app';
         $host   = $All_config['params']['ES_conn']['host']?$All_config['params']['ES_conn']['host']:'192.168.1.60';
         $port   = $All_config['params']['ES_conn']['port']?$All_config['params']['ES_conn']['port']:'39200'; 

         //init
         $this->setIndex($index);
         $this->setType($type);
		 $this->setRoot(ROOT);
		 $this->setLogdir($All_config['params']['LOG_dir']);
		 $this->setLogflag($All_config['params']['LOG_flag']);

	    $_config  = array(
	           'host' =>$host, 
	           'port' =>$port,
	    );

        //生成请求对象
        $elasticaClient = new Elastica\Client($_config); // localhost:9200

        //////////////////////生成文档 start //////////////////////

		//新增记录数组集
        $arr            = array();
        $docCountArr    = array();
		

        //导入monolog 入es 
	    $arr = $this->monologInEs();
	    //添加文档到ES
		if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	   
	    $docCountArr[]  = count($arr);
	   $txt  = "==========================导入monolog=======================================";
       //print_r($arr);
       $txt .= "=================================================================";

       //日志操作
	   $this->rewritetolog('导入monolog', $txt);
       
	    //导入thriftlog 入es 
	    $arr = $this->thriftlogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "============================导入thriftlog=====================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入thriftlog', $txt);

	    //导入phplog 入es 
	    $arr = $this->phplogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	     $docCountArr[]  = count($arr);
	   $txt  = "============================导入phplog=====================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入phplog', $txt);

	   //导入accesslog 入es 
	    $arr = $this->accesslogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入accesslog======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入accesslog', $txt);
	   
	   //导入phpfpmlog 入es 
		$arr = $this->phpfpmlogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入phpfpmlog======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入phpfpmlog', $txt);
	   
	   	//导入nginxlogInEs 入es 
		$arr = $this->nginxlogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入nginxlogInEs======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入nginxlogInEs', $txt);
	   
	   	//导入yuyuecalllogInEs 入es 
		$arr = $this->yuyuecalllogInEs();
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入yuyuecalllogInEs======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入yuyuecalllogInEs', $txt);
	   
	   //导入lunciyuyuelogInEs 入es 
		$arr = $this->lunciyuyuelogInEs();
		//print_r($arr);
		//exit;
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入lunciyuyuelogInEs======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入lunciyuyuelog', $txt);
	   
	    //导入reqyuyuelogInEs 入es 
		$arr = $this->reqyuyuelogInEs();
		//print_r($arr);
		//exit;
	    //添加文档到ES
	   	if(count($arr)){
			 $reindex = $elasticaClient->addDocuments($arr);
		}
	    $docCountArr[]  = count($arr);
	   $txt  = "===========================导入reqyuyuelogInEs======================================";
       //print_r($arr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('导入reqyuyuelog', $txt);

       $txt   = "================================docCountArr=================================";
       //print_r($docCountArr);
       $txt  .= json_encode($docCountArr);
       $txt  .= "=================================================================";
       //日志操作
	   $this->rewritetolog('documentSun:', $txt);

        //////////////////////生成文档 end  //////////////////////

        $txt = '===================== all the end ========='.date("Y-m-d h:i:sa", time()).'=================';
        //日志操作
	   $this->rewritetolog('alltheend ', $txt);
    }

	/*
	** 
	* 导入monolog 入es 
	* return array();
	*/ 
	function monologInEs(){ //$document

		//新增记录数组集
        $arr            = array();

		//$fileName  = ROOT.'/data/monolog_20150203.txt';
		
    	//$fileName  = ROOT.'/data/monolog_';
	    //$fileName  = $fileName.date('Ymd').".txt";
		
        $dir      = $this->_logdir;
        $fileName = $dir['monologDir'];
		
        //读取方式3
		$logarr = $this->getLogArr($fileName,'monologIndex');

		//处理LOG数组
		foreach ($logarr as $key => $value) {

			//value str 转换 json 对象
			$monologArr = array();
			$monologArr = json_decode($value, true); 

            if(is_array($monologArr)){

            //处理第一条记录
			$logtime ='';
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';

            foreach ($monologArr as $k => $v) {

	                if($k == 'time'){
	                   $logtime =$v;
	                }

					if($k == 'request'){
						foreach ($v as $k2 => $v2) {

							if($k2 == 'module') {
								$cl= $v2;
							}elseif($k2 == 'model'){
                                $cl= $v2;
							}
							if($k2 == 'action') {$m= $v2;}
						}
					}
			    }

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $cl.'-'.$m.'-'.$time.'-'.strtotime($logtime);
			$tsn  = (int)strtotime($logtime)*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'monolog',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$logtime,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>'',
			         'ip'  =>'',
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType($this->_type);
			 $document->setIndex($this->_index);

			 $arr[] = $document;
            }
		}
        return $arr;
	}

	/*
	** 
	* 导入thriftlog 入es 
	* return array();
	*/ 
	function thriftlogInEs(){ 

		//新增记录数组集
        $arr            = array();

        //$fileName  = ROOT.'/data/LOGV2_THRIFT_';
	    //$fileName  = $fileName.date('Ymd').".log";
		
		$dir      = $this->_logdir;
        $fileName = $dir['thriftlogDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'thriftlogIndex');

		//处理LOG数组
		foreach ($logarr as $key => $value) {

			//value str 转换 json 对象
			$monologArr = array();
			$monologArr = json_decode($value, true); 

           if(is_array($monologArr)){

            //处理第一条记录
			$logtime ='';
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';
            $ip      ='';
            $ag      ='';

            foreach ($monologArr as $k => $v) {

	                if($k == 'REQUEST_TIME'){
	                   $logtime =$v['sec'];
	                }

	                if($k == 'REMOTE_ADDR'){
	                   $ip =$v;
	                }

	                if($k == 'HTTP_USER_AGENT'){
	                   $ag =$v;
	                }

					if($k == 'data'){
						foreach ($v as $k2 => $v2) {

							if($k2 == 'methodName') {$cl= $v2;}
							if($k2 == 'param') {
								foreach ($v2 as $k3 => $v3) {
									if($k3 == 'sort') {
										foreach ($v3 as $k4 => $v4) {
											if($v4['classname']) {
												$m= $v4['classname'];
											}

										}
									}

								}
							}
						}
					}
			    }

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $cl.'-'.$m.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'Thriftlog',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>$ag,
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType($this->_type);
			 $document->setIndex($this->_index);

			 $arr[] = $document;
            }
		}
        return $arr;
	}

	/*
	** 
	* 导入phplog 入es 
	* return array();
	*/ 
	function phplogInEs(){ 

		//新增记录数组集
        $arr            = array();

        //$fileName  = ROOT.'/data/LOGV2_PHP_';
	    //$fileName  = $fileName.date('Ymd').".log";
		
	    $dir      = $this->_logdir;
        $fileName = $dir['phplogDir'];


        //读取方式3
		$logarr = $this->getLogArr($fileName,'phplogIndex');

        //新增记录数组集
        $arr            = array();
		//处理LOG数组
		foreach ($logarr as $key => $value) {

			//value str 转换 json 对象
			$monologArr = array();
			$monologArr = json_decode($value, true); 

           if(is_array($monologArr)){

            //处理第一条记录
			$logtime ='';
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';
            $ip      ='';
            $ag      ='';
            $file    ='';
            $ln      =0;
            $uid     ='';

            foreach ($monologArr as $k => $v) {

	                if($k == 'REQUEST_TIME'){
	                   $logtime =$v['sec'];
	                }

	                if($k == 'REMOTE_ADDR'){
	                   $ip =$v;
	                }

	                if($k == 'HTTP_USER_AGENT'){
	                   $ag =$v;
	                }

					if($k == 'data'){
						foreach ($v as $k2 => $v2) {

							if($k2 == 'ERRFILE') {$file= $v2;}
							if($k2 == 'ERRLINE') {$ln  = (int)$v2;}
							if($k2 == 'REQUEST') {
								foreach ($v2 as $k3 => $v3) {
									if($k3 == 'model') {$cl= $v3;}
									if($k3 == 'action') {$m= $v3;}
									if($k3 == 'uid') {$uid= $v3;}
								}
							}
						}
					}
			    }

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $cl.'-'.$m.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'Phplog',
			         'sid' =>'',
			         'file'=>$file,
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>$ln,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>$ag,
			         'ip'  =>$ip,
			         'uid' =>$uid,
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType($this->_type);
			 $document->setIndex($this->_index);

			 $arr[] = $document;

            }
		}
        return $arr;
	}

	/*
	** 
	* 导入accesslog 入es 
	* return array();
	*/ 
	function accesslogInEs(){ 

		//新增记录数组集
        $arr            = array();


        //$fileName  = ROOT.'/data/LOGV2_ACCESS_';
	    //$fileName  = $fileName.date('Ymd').".log";
		
	    $dir      = $this->_logdir;
        $fileName = $dir['accesslogDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'accesslogIndex');

        //新增记录数组集
        $arr            = array();
		//处理LOG数组
		foreach ($logarr as $key => $value) {

			//value str 转换 json 对象
			$monologArr = array();
			$monologArr = json_decode($value, true); 

           if(is_array($monologArr)){

            //处理第一条记录
			$logtime ='';
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';
            $ip      ='';
            $ag      ='';

            foreach ($monologArr as $k => $v) {

	                if($k == 'REQUEST_TIME'){
	                   $logtime =$v['sec'];
	                }

	                if($k == 'REMOTE_ADDR'){
	                   $ip =$v;
	                }

	                if($k == 'HTTP_USER_AGENT'){
	                   $ag =$v;
	                }

					if($k == 'data'){
						foreach ($v as $k2 => $v2) {


							if($k2 == 'req') {
								foreach ($v2 as $k3 => $v3) {
									if($k3 == 'model') {$cl= $v3;}
									if($k3 == 'action') {$m= $v3;}
								}
							}
						}
					}
			    }

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $cl.'-'.$m.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'Accesslog',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>$ag,
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType($this->_type);
			 $document->setIndex($this->_index);

			 $arr[] = $document;
            }
		}
        return $arr;
	}
	
	
	/*
	** 
	* 导入phpfpmlog 入es 
	* return array();
	*/ 
	function phpfpmlogInEs(){ 

		//新增记录数组集
        $arr            = array();

		$dir      = $this->_logdir;
        $fileName = $dir['phpfpmlogDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'phpfpmlogIndex');
		//没有数据则直接返回
		$countlogarr = count($logarr);
        if($countlogarr < 2){
			return $arr;
		}


		//处理LOG数组
		foreach ($logarr as $key => &$value) {
			
		$findme1    = '[';
		$findme2    = ']';
		$mystring   = $value;
		$timestr    ='';

		//获取时间日期结束位置
		$pos2       = $this->findStrindex($mystring,$findme2);
		if ($pos2 !== false) {
			$timestr = substr($mystring,0,$pos2);
		}
        //获取时间日期开始位置
		$pos1       = $this->findStrindex($timestr,$findme1);
		if ($pos1 !== false) {
			$timestr = substr($timestr,$pos1+1);
		}else{
			$value = '['.$value; 
		}
		
            //处理第一条记录
			$logtime = strtotime($timestr);
            $_id     ='';
            $tsn     ='';
            $txt     ='';


			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $key.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'Phpfpm',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>'',
			         'm'   =>'',
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>'',
			         'ip'  =>'',
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType('phpfpm');
			 $document->setIndex($this->_index);

			 $arr[] = $document;
         
		}
        return $arr;
	}

	/*
	** 
	* 导入nginxlog 入es 
	* return array();
	*/ 
	function nginxlogInEs(){ 

		//新增记录数组集
        $arr            = array();
		
		$dir      = $this->_logdir;
        $fileName = $dir['nginxlogDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'nginxlogIndex');
		//没有数据则直接返回
		$countlogarr = count($logarr);
        if($countlogarr < 2){
			return $arr;
		}

		//处理LOG数组
		foreach ($logarr as $key => $value) {

			    $findme1    = '[';
				$findme2    = ',';
				$mystring   = $value;
				$timestr    ='';
				$ip         ='';
                //获取时间日期位置
				$pos2       = $this->findStrindex($mystring,$findme1);
				if ($pos2 !== false) {
					$timestr = substr($mystring,0,$pos2);
				}
                //获取IP 开始与结束位置
				$pos1       = $this->findStrindex($mystring,$findme2,1);
				$pos3       = $this->findStrindex($mystring,$findme2,2);

				if ($pos1 !== false && $pos3 !== false) {
					$ip    = substr($mystring,$pos1+1,$pos3-$pos1-1);
				}


            //处理第一条记录
			$logtime = strtotime($timestr);
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';
            $ip      = $ip;
            $ag      ='';

           

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $key.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'Nginx',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>'ERROR',
			         'lvn' =>40000,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>$ag,
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType('nginx');
			 $document->setIndex($this->_index);

			 $arr[] = $document;

		}
        return $arr;
	}
	
	
	/*
	** 
	* 导入yuyuecalllogInEs 入es 
	* return array();
	*/ 
	function yuyuecalllogInEs(){ 

		//新增记录数组集
        $arr            = array();
		
		$dir      = $this->_logdir;
        $fileName = $dir['yuyuecallDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'yuyuecallIndex');
		//echo '<pre>';
		//print_r($logarr);
		//exit;
		//没有数据则直接返回
		$countlogarr = count($logarr);
        if($countlogarr < 2){
			return $arr;
		}

		//处理LOG数组
		foreach ($logarr as $key => $value) {

			    $findme1    = '[';
				$findme2    = ']';
				$mystring   = $value;
				$timestr    ='';
				$ip         ='';
                //获取时间日期位置
				$pos2       = $this->findStrindex($mystring,$findme1);
				if ($pos2 !== false) {
					$timestr = substr($mystring,0,$pos2);
				}
                //获取IP 开始与结束位置
				$pos1       = $this->findStrindex($mystring,$findme2,1);
				$pos3       = $this->findStrindex($mystring,$findme2,2);

				if ($pos1 !== false && $pos3 !== false) {
					$ip    = substr($mystring,$pos1+1,$pos3-$pos1-1);
				}


			$ip          = str_replace('[', '', $ip);
			$ip          = trim($ip);
			$lvArr       = explode(':',$ip);
			
			if($lvArr[0] == 'IP'){
				$lv = 'INFO';
			    $lvn=20000;
			}else{
				$lv = 'ERROR';
			    $lvn=40000;
				$ip = '';
			}
			/*      
			'ERROR'=>'40000',//40000
            'WARN'=>'30000',//30000
            'INFO'=>'20000',//20000
            'DEBUG'=>'10000',//10000
            'TRACE'=>'5000',//5000
			*/
            //处理第一条记录
			$logtime = strtotime($timestr);
            $_id     ='';
            $cl      ='';
            $m       ='';
            $tsn     ='';
            $txt     ='';
            $ip      = $ip;
            $ag      ='';

           

			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $key.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
			         'proj'=>'yuyuecall',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>$lv,
			         'lvn' =>$lvn,
			         'th'  =>'',
			         'cl'  =>$cl,
			         'm'   =>$m,
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>$ag,
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType('yuyuecall');
			 $document->setIndex($this->_index);

			 $arr[] = $document;

		}
        return $arr;
	}
	
	/*
	** 
	* 导入lunciyuyuelog 入es 
	* return array();
	*/ 
	function lunciyuyuelogInEs(){ 

		//新增记录数组集
        $arr            = array();

		$dir      = $this->_logdir;
        $fileName = $dir['lunciyuyueDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'lunciyuyueIndex');

		
		//没有数据则直接返回
		$countlogarr = count($logarr);
        if($countlogarr < 2){
			return $arr;
		}


		//处理LOG数组
		foreach ($logarr as $key => &$value) {
			
		$findme1    = '[';
		$findme2    = ']';
		$mystring   = $value;
		$timestr    ='';
		$ip         ='';

		//获取时间日期结束位置
		$pos2       = $this->findStrindex($mystring,$findme2);
		if ($pos2 !== false) {
			$timestr = substr($mystring,0,$pos2);
		}
        //获取时间日期开始位置
		$pos1       = $this->findStrindex($timestr,$findme1);
		if ($pos1 !== false) {
			$timestr = substr($timestr,$pos1+1);
		}else{
			$value = '['.$value; 
		}
		
        //获取IP 开始与结束位置
		$pos1       = $this->findStrindex($value,$findme2,2);
		$pos3       = $this->findStrindex($value,$findme2,3);

		if ($pos1 !== false && $pos3 !== false) {
			$ip    = substr($value,$pos1+1,$pos3-$pos1-1);
		}


	    $ip          = str_replace('[', '', $ip);
		$ip          = trim($ip);
		$lvArr       = explode(':',$ip);
			
		if($lvArr[0] == 'IP'){
			$lv = 'INFO';
			$lvn=20000;
		}else{
			$lv = 'ERROR';
			$lvn=40000;
			$ip = '';
		}

            //处理第一条记录
			$logtime = strtotime($timestr);
            $_id     ='';
            $tsn     ='';
            $txt     ='';


			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $key.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
					 'proj'=>'lunciyuyue',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>$lv,
			         'lvn' =>$lvn,
			         'th'  =>'',
			         'cl'  =>'',
			         'm'   =>'',
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>'',
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType('lunciyuyue');
			 $document->setIndex($this->_index);

			 $arr[] = $document;
         
		}
        return $arr;
	}
	
	/*
	** 
	* 导入reqyuyuelog 入es 
	* return array();
	*/ 
	function reqyuyuelogInEs(){ 

		//新增记录数组集
        $arr            = array();

		$dir      = $this->_logdir;
        $fileName = $dir['reqyuyueDir'];

        //读取方式3
		$logarr = $this->getLogArr($fileName,'reqyuyueIndex');
		//没有数据则直接返回
		$countlogarr = count($logarr);
        if($countlogarr < 2){
			return $arr;
		}


		//处理LOG数组
		foreach ($logarr as $key => &$value) {
			
		$findme1    = '[';
		$findme2    = ']';
		$mystring   = $value;
		$timestr    ='';
		$ip         ='';

		//获取时间日期结束位置
		$pos2       = $this->findStrindex($mystring,$findme2);
		if ($pos2 !== false) {
			$timestr = substr($mystring,0,$pos2);
		}
        //获取时间日期开始位置
		$pos1       = $this->findStrindex($timestr,$findme1);
		if ($pos1 !== false) {
			$timestr = substr($timestr,$pos1+1);
		}else{
			$value = '['.$value; 
		}
		
        //获取IP 开始与结束位置
		$pos1       = $this->findStrindex($value,$findme2,2);
		$pos3       = $this->findStrindex($value,$findme2,3);

		if ($pos1 !== false && $pos3 !== false) {
			$ip    = substr($value,$pos1+1,$pos3-$pos1-1);
		}


	    $ip          = str_replace('[', '', $ip);
		$ip          = trim($ip);
		$lvArr       = explode(':',$ip);
			
		if($lvArr[0] == 'IP'){
			$lv = 'INFO';
			$lvn=20000;
		}else{
			$lv = 'ERROR';
			$lvn=40000;
			$ip = '';
		}

            //处理第一条记录
			$logtime = strtotime($timestr);
            $_id     ='';
            $tsn     ='';
            $txt     ='';


			//生成文档对象
			$document = new Elastica\Document();
			$time = time();
			$_id  = $key.'-'.$time.'-'.$logtime;
			$ts   = date('Y/m/d H:i:s', $logtime);
			$tsn  = (int)$logtime*1000;
			$txt  = $value;
			$data = array(
					 'proj'=>'reqyuyue',
			         'sid' =>'',
			         'file'=>'',
			         'iid' =>'',
			         'seq' =>0,
			         'ts'  =>$ts,
			         'tsn' =>$tsn,
			         'lv'  =>$lv,
			         'lvn' =>$lvn,
			         'th'  =>'',
			         'cl'  =>'',
			         'm'   =>'',
			         'ln'  =>0,
			         'bsid'=>'',
			         'esid'=>'',
			         'txt' =>$txt,
			         'ex'  =>'',
			         'ag'  =>'',
			         'ip'  =>$ip,
			         'uid' =>'',
			 );
			 $document->setId($_id);
			 $document->setData($data);
			 $document->setType('reqyuyue');
			 $document->setIndex($this->_index);

			 $arr[] = $document;
         
		}
        return $arr;
	}

	
	
	/**
	 * @功能：获取日志数组
	 * @参数：$fileName=>获取日志的路径,
	 * $indexType=> 要获取的类型 
	 * $getNum=> 要获取的行数
	 * $return => 返回结果集, 
	 */ 
	function del_dir(){

        $now        = time();
		$time       = strtotime('-1 day', $now);  
        $yday       = date('Ymd', $time); 
		$root = $this->_root;
		$indexName  = $root.'/log/logIndex'.$yday.'.txt';
		if (file_exists($indexName)) {
		$result=unlink ($indexName);
		}

	}

	/**
	 * @功能：获取日志数组
	 * @参数：$fileName=>获取日志的路径,
	 * $indexType=> 要获取的类型 
	 * $getNum=> 要获取的行数
	 * $return => 返回结果集, 
	 */ 
	function getLogArr($fileName,$indexType,$getNum=100) { 

            $root = $this->_root;
		    $indexName  = $root.'/log/logIndex'.date('Ymd').'.txt';

	    	$txtIndex = @file_get_contents($indexName); 
	    	$arrIndex = explode("\n", $txtIndex);
	    	$IndexArr =array(
				'monologIndex'=>'0',
				'thriftlogIndex'=>'0',
				'phplogIndex'=>'0',
				'accesslogIndex'=>'0',
				'phpfpmlogIndex'=>'0',
				'nginxlogIndex'=>'0',
				'yuyuecallIndex'=>'0',
				'lunciyuyueIndex'=>'0',
				'reqyuyueIndex'=>'0',
				);

	    	if($arrIndex[0]){

	    	   $allindexArr = json_decode($arrIndex[0], true); 
	           if(is_array($allindexArr)){
	           	$IndexArr = $allindexArr;
	           }

	    	}else{

				$indexJson = json_encode($IndexArr);
				$this->writeFile($indexName,$indexJson,'w');

	    	}
			//del dir for yesteday
		    //检查是否有昨天Index文件
			$this->del_dir();

		    $logarr  = array();
		    $jsonarr =array();
	        $findex  = 0;

			if (!file_exists($fileName)) {
                 //日志操作
				$this->rewritetolog('fileName', " this is no file in $fileName", 404);
			    return $logarr;
			}

	        switch ($indexType) {
	        	case 'monologIndex':
	        		$findex = isset($IndexArr['monologIndex']) ? $IndexArr['monologIndex'] : 0;
	        		break;
	        	case 'thriftlogIndex':
	        		$findex = isset($IndexArr['thriftlogIndex']) ? $IndexArr['thriftlogIndex'] : 0;
	        		break;
	           case 'phplogIndex':
	        		$findex = isset($IndexArr['phplogIndex']) ? $IndexArr['phplogIndex'] : 0;
	        		break;
	           case 'accesslogIndex':
	        		$findex = isset($IndexArr['accesslogIndex']) ? $IndexArr['accesslogIndex'] : 0;
	        		break;
			  case 'phpfpmlogIndex':
	        		$findex = isset($IndexArr['phpfpmlogIndex']) ? $IndexArr['phpfpmlogIndex'] : 0;
	        		break;
			  case 'nginxlogIndex':
	        		$findex = isset($IndexArr['nginxlogIndex']) ? $IndexArr['nginxlogIndex'] : 0;
	        		break;
			  case 'yuyuecallIndex':
	        		$findex = isset($IndexArr['yuyuecallIndex']) ? $IndexArr['yuyuecallIndex'] : 0;
	        		break;
			  case 'lunciyuyueIndex':
	        		$findex = isset($IndexArr['lunciyuyueIndex']) ? $IndexArr['lunciyuyueIndex'] : 0;
	        		break;
			  case 'reqyuyueIndex':
	        		$findex = isset($IndexArr['reqyuyueIndex']) ? $IndexArr['reqyuyueIndex'] : 0;
	        		break;
	        	default:
	        		# code...
	        		break;
	        }
			
			$fp = @fopen($fileName, 'r');
			$i = 0;
			$content = '';
			fseek($fp, $findex);
			while(!feof($fp) && $i++< $getNum)
		    //while(!feof($fp))
			{
			$content .= fgets($fp);
			$findex = ftell($fp);//记录findex以便下次读取
			} 
			if($indexType=='phpfpmlogIndex' || $indexType=='lunciyuyueIndex' || $indexType=='reqyuyueIndex'){//phpfpm, lunciyuyue, reqyuyue日志处理方式 
				$logarr = explode("\n[", $content);
			}else{
				$logarr = explode("\n", $content);
			}
	         

	        switch ($indexType) {
	        	case 'monologIndex':

	        	    $jsonarr =array(
							'monologIndex'=>$findex,
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
	        	case 'thriftlogIndex':
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$findex,
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
	           case 'phplogIndex':
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$findex,
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
	           case 'accesslogIndex':
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$findex,
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
			  case 'phpfpmlogIndex': 
			  
			        $count = count($logarr);
					if($count>1){
						$first = $logarr[0];
						$end   = end($logarr);

						$endarrName  = $root.'/log/endarr.php';
						$txtIndex = @file_get_contents($endarrName); 
						$arrIndex = explode("\n", $txtIndex);
                        $endstritem =array(
							'phpfpmendstr'=>'',
							'lunciyuyueendstr'=>'',
							'reqyuyueendstr'=>'',
							);
						$endarr = array();
						
						if($arrIndex[0]){

						   $allindexArr = json_decode($arrIndex[0], true); 
						  
						   if(is_array($allindexArr)){
							$endarr = $allindexArr;
						   }

						}
						
						//首字符
						$firstStr = substr( $first, 0, 1 );
						if($firstStr == '['){
							if(@$endarr['phpfpmendstr']){
								$logarr[$count-1] = $endarr['phpfpmendstr'];
							}
							$endstritem =array(
								'phpfpmendstr'=>$end,
								'lunciyuyueendstr'=>$endarr['lunciyuyueendstr'],
							    'reqyuyueendstr'=>$endarr['reqyuyueendstr'],
							);
						}else{
							$allendstr = $endarr['phpfpmendstr'].$first;
							$logarr[0] = $allendstr;
							$endstritem =array(
							'phpfpmendstr'=>$end,
							'lunciyuyueendstr'=>$endarr['lunciyuyueendstr'],
							'reqyuyueendstr'=>$endarr['reqyuyueendstr'],
							);
						}
						
						$indexJson = json_encode($endstritem);
					    $this->writeFile($endarrName,$indexJson,'w');

					}
			  
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$findex,
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
			  case 'nginxlogIndex':
			  
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$findex,
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
			case 'yuyuecallIndex':
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$findex,
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
			case 'lunciyuyueIndex':
			//[2015-06-24 13:41:01]   [info]  [IP: 127.0.0.1] 坐席号 [8062] 20秒未上报，自动取消激活！
			        $count = count($logarr);
					if($count>1){
						$first = $logarr[0];
						$end   = end($logarr);

						$endarrName  = $root.'/log/endarr.php';
						$txtIndex = @file_get_contents($endarrName); 
						$arrIndex = explode("\n", $txtIndex);
						
                        $endstritem =array(
							'phpfpmendstr'=>'',
							'lunciyuyueendstr'=>'',
							'reqyuyueendstr'=>'',
							);
						$endarr = array();
						
						if($arrIndex[0]){

						   $allindexArr = json_decode($arrIndex[0], true); 
						  
						   if(is_array($allindexArr)){
							$endarr = $allindexArr;
						   }

						}
						
						//首字符
						$firstStr = substr( $first, 0, 1 );
	
						
						if($firstStr == '['){
							if(@$endarr['lunciyuyueendstr']){
								$logarr[$count-1] = $endarr['lunciyuyueendstr'];
							}
							$endstritem =array(
								'phpfpmendstr'=>$endarr['phpfpmendstr'],
								'lunciyuyueendstr'=>$end,
							    'reqyuyueendstr'=>$endarr['reqyuyueendstr'],
							);
						}else{
							$allendstr = $endarr['lunciyuyueendstr'].$first;
							$logarr[0] = $allendstr;
							$endstritem =array(
							'phpfpmendstr'=>$endarr['phpfpmendstr'],
							'lunciyuyueendstr'=>$end,
							'reqyuyueendstr'=>$endarr['reqyuyueendstr'],
							);
						}
		
						$indexJson = json_encode($endstritem);
					    $this->writeFile($endarrName,$indexJson,'w');
						

					}
			
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$findex,
							'reqyuyueIndex'=>$IndexArr['reqyuyueIndex'],
							);
	        		break;
			case 'reqyuyueIndex':
			
			$count = count($logarr);
					if($count>1){
						$first = $logarr[0];
						$end   = end($logarr);

						$endarrName  = $root.'/log/endarr.php';
						$txtIndex = @file_get_contents($endarrName); 
						$arrIndex = explode("\n", $txtIndex);
                        $endstritem =array(
							'phpfpmendstr'=>'',
							'lunciyuyueendstr'=>'',
							'reqyuyueendstr'=>'',
							);
						$endarr = array();
						
						if($arrIndex[0]){

						   $allindexArr = json_decode($arrIndex[0], true); 
						  
						   if(is_array($allindexArr)){
							$endarr = $allindexArr;
						   }

						}
						
						//首字符
						$firstStr = substr( $first, 0, 1 );
						if($firstStr == '['){
							if(@$endarr['reqyuyueendstr']){
								$logarr[$count-1] = $endarr['reqyuyueendstr'];
							}
							$endstritem =array(
								'phpfpmendstr'=>$endarr['phpfpmendstr'],
								'lunciyuyueendstr'=>$endarr['lunciyuyueendstr'],
							    'reqyuyueendstr'=>$end,
							);
						}else{
							$allendstr = $endarr['reqyuyueendstr'].$first;
							$logarr[0] = $allendstr;
							$endstritem =array(
							'phpfpmendstr'=>$endarr['phpfpmendstr'],
							'lunciyuyueendstr'=>$endarr['lunciyuyueendstr'],
							'reqyuyueendstr'=>$end,
							);
						}
						
						$indexJson = json_encode($endstritem);
					    $this->writeFile($endarrName,$indexJson,'w');

					}
	        		$jsonarr =array(
							'monologIndex'=>$IndexArr['monologIndex'],
							'thriftlogIndex'=>$IndexArr['thriftlogIndex'],
							'phplogIndex'=>$IndexArr['phplogIndex'],
							'accesslogIndex'=>$IndexArr['accesslogIndex'],
							'phpfpmlogIndex'=>$IndexArr['phpfpmlogIndex'],
							'nginxlogIndex'=>$IndexArr['nginxlogIndex'],
							'yuyuecallIndex'=>$IndexArr['yuyuecallIndex'],
							'lunciyuyueIndex'=>$IndexArr['lunciyuyueIndex'],
							'reqyuyueIndex'=>$findex,
							);
	        		break;
	        	default:
	        		# code...
	        		break;
	        }

			

			$indexJson = json_encode($jsonarr);
			$this->writeFile($indexName,$indexJson,'w');
			

	    	return $logarr;
	}

	 /**
     * Sets specific index values (updates and keeps default values)
     *
     * @param  string $index Params
     * @return $this
     */
    public function setIndex($index)//setType($type)
    {
          $this->_index= $index;

        return $this;
    }

     /**
     * Sets specific type values (updates and keeps default values)
     *
     * @param  string $type Params
     * @return $this
     */
    public function setType($type)
    {
        $this->_type = $type;

        return $this;
    }
	
	 /**
     * Sets specific root values (updates and keeps default values)
     *
     * @param  string $root Params
     * @return $this
     */
    public function setRoot($root)
    {
        $this->_root = $root;

        return $this;
    }
	
	/**
     * Sets specific logdir values (updates and keeps default values)
     *
     * @param  string $logdir Params
     * @return $this
     */
    public function setLogdir($logdir)
    {
        $this->_logdir = $logdir;

        return $this;
    }
	
	/**
     * Sets specific logflag values (updates and keeps default values)
     *
     * @param  string $logflag Params
     * @return $this
     */
    public function setLogflag($logflag)
    {
        $this->_logflag = $logflag;
        return $this;
    }
	
	/**
     *
     * @param  string $string Params
	 * @param  string $find   Params
	 * @param  int    $num    Params
     * @return $pos
     */
    public function findStrindex($string, $find, $num=1)
    {
        	$pos = -1;
			$n   = 0;
			do{
				$pos = strpos($string, $find, $pos+1);
				$n++;
				if($n==$num){
					break;
				}
			}while($pos!==false);
        return $pos;
    }
	


	/*
	** 
	* 写文件 
	* @param string $file 文件路径 
	* @param string $str 写入内容 
	* @param char $mode 写入模式 
	*/ 
	function writeFile($file,$str,$mode='w'){ 
		$oldmask = @umask(0); 
		$fp = @fopen($file,$mode); 
		@flock($fp, 3); 
		if(!$fp){ 
		 Return false; 

		} else { 
			@fwrite($fp,$str); 
			@fclose($fp); 
			@umask($oldmask); 
			Return true; 
		} 
	}

	/**
	 * @功能：日志记录
	 * @参数：$intype => 要记录日志的类型,
	 * $txt => 返回结果集, 
	 * $args => 返回结果状态，0表示成功，非0表示失败
	 * $logger => 是否要记录日志
	 * @返回：若转换成功返回true,否则返回false或直接跳出
	 * 显示行号 __LINE__
	 */  
	function rewritetolog($intype='', $txt='', $args='', $logger =true) {

		if($logger){
			$log = '#Suc#';

			$flag = $this->_logflag;
			if($flag){
				  if($args){
				   $log = '#Err#';
				  }
				  $log = $log.$intype.':'.date("Y-m-d H:i:s").":#txt#".$txt."#args#".$args."<br>\n";
				  $root = $this->_root;
				  $fileName  = $root.'/log/';
				  $fileName = $fileName.date('Y-m-d').".log";
				  $this->writeFile($fileName,$log,'a');
				
			}else{
				
			    if($args){
				   $log = '#Err#';
				//}
				  $log = $log.$intype.':'.date("Y-m-d H:i:s").":#txt#".$txt."#args#".$args."<br>\n";
				  $root = $this->_root;
				  $fileName  = $root.'/log/';
				  $fileName = $fileName.date('Y-m-d').".log";
				  $this->writeFile($fileName,$log,'a');
				}
				
			}
		}
	}
}



$applog = new ApplogCommand();
$applog->run();


<?php
/**
 * **************************************************************************************
 * Description   : 自动化执行 命令行模式 
 *                 monolog,Thriftlog,Phplog,Accesslog,php-fpm,nginx 
 *
 *				   导入到 ES
 * Filename      : AlllogCommand.php
 * Create time   : 2015-06-27
 * Last modified : 2015-06-27 
 * update        : bfire.lai
 * $getNum       :第个文件读取行数 844行
 * **************************************************************************************
 */
class AlllogCommand 
{
	/*@var _index*/
    protected $_index = '';

    /*@var _type*/
    protected $_type  = '';
	
	/*@var _root*/
	protected $_root  = '';
	
	/*@var _logdir */
	protected $_logdir  = array();
	
     /*@var _logdir*/
	protected $_logflag  = 0;
	
	/* 程序执行入口*/
    public function run() {
		
		//网站根目录
		if (!defined('ROOT')) {                       
			define('ROOT', dirname(__FILE__));
			//目前root 只显示到 D:\wamp\www\tboss\log2es
		}

		//导入 ES 与 log_Info 配置
        $all_Config = require_once(ROOT.'/allconfig.php');
		
		 //库与表
         $index    = $all_Config['params']['es_Conn']['_index'];
         $host     = $all_Config['params']['es_Conn']['host'];
         $port     = $all_Config['params']['es_Conn']['port']; 
		 $log_Info = $all_Config['params']['log_Info'];
		 
		//init
         $this->setIndex($index);
         //$this->setType($type);
		 $this->setRoot(ROOT);
		 $this->setLogdir($all_Config['params']['log_Info']);
		 $this->setLogflag($all_Config['params']['log_Flag']);
		 $countLog = count($log_Info);
		 

		//////////////////////生成文档 start //////////////////////

		//新增记录数组集
        $arr            = array();
        $docCountArr    = array();
		
	   //////////////////////生成文档 end //////////////////////
	   /*
	   echo '<pre>';
	   print_r($all_Config);
	   echo '<br>+++<br>\r\n';
	   print_r(ROOT);
	   exit;
      */
	   $ts = array();
	   if(is_array($log_Info) && $countLog){
		   foreach ($log_Info as $key => $value){
			   /*echo '<pre>';
			   print_r($key);
			   echo '<br>+++<br>\r\n';
			   print_r($value);
			   exit;*/
			   switch($value['_logtype']){
				   case 1 :
				   $ts [1][]=  $value['_dir'].'+'.$value['_type'].'+'.$value['_proj'].'+'.$value['_iid'].'+'.$value['_getNum'].'++';
				   
				   break;
				   case 2 :
				   $ts [2][]=  $value['_dir'].'+'.$value['_type'].'+'.$value['_proj'].'+'.$value['_iid'].'+'.$value['_getNum'].'++';
				   break;
				   case 3 :
				   $ts [3][]=  $value['_dir'].'+'.$value['_type'].'+'.$value['_proj'].'+'.$value['_iid'].'+'.$value['_getNum'].'++';
				   break;
				   case 4 :
				   $ts [4][]=  $value['_dir'].'+'.$value['_type'].'+'.$value['_proj'].'+'.$value['_iid'].'+'.$value['_getNum'].'++';
				   break;
				   case 5 :
				   $ts [5][]=  $value['_dir'].'+'.$value['_type'].'+'.$value['_proj'].'+'.$value['_iid'].'+'.$value['_getNum'].'++';
				   break;
				   default:
	        		# code...
	        		break;
			   }
		   }
	   }
	   
	   print_r($ts);
	   exit;

	}
	
	 /**
     * Sets specific index values (updates and keeps default values)
     * @param  string $index Params
     * @return $this
     */
    public function setIndex($index)
    {
        $this->_index= $index;
        return $this;
    }

     /**
     * Sets specific type values (updates and keeps default values)
     * @param  string $type Params
     * @return $this
     */
    public function setType($type)
    {
        $this->_type = $type;
        return $this;
    }
	
	 /**
     * Sets specific root values (updates and keeps default values)
     * @param  string $root Params
     * @return $this
     */
    public function setRoot($root)
    {
        $this->_root = $root;
        return $this;
    }
	
	/**
     * Sets specific logdir values (updates and keeps default values)
     * @param  string $logdir Params
     * @return $this
     */
    public function setLogdir($logdir)
    {
        $this->_logdir = $logdir;
        return $this;
    }
	
	/**
     * Sets specific logflag values (updates and keeps default values)
     * @param  string $logflag Params
     * @return $this
     */
    public function setLogflag($logflag)
    {
        $this->_logflag = $logflag;
        return $this;
    }
	
	/**
	 * 查找某字符在字符串中的位置
     * @param  string $string Params
	 * @param  string $find   Params
	 * @param  int    $num    Params
     * @return $pos
     */
    public function findStrindex($string, $find, $num=1)
    {
        $pos = -1;
		$n   = 0;
		do{
			$pos = strpos($string, $find, $pos+1);
			$n++;
			if($n==$num){
				break;
			}
		}while($pos!==false);
        return $pos;
    }
	
	/*
	** 
	* 写文件 
	* @param string $file 文件路径 
	* @param string $str 写入内容 
	* @param char $mode 写入模式 
	*/ 
	function writeFile($file,$str,$mode='w'){ 
		$oldmask = @umask(0); 
		$fp = @fopen($file,$mode); 
		@flock($fp, 3); 
		if(!$fp){ 
		 Return false; 

		} else { 
			@fwrite($fp,$str); 
			@fclose($fp); 
			@umask($oldmask); 
			Return true; 
		} 
	}

	/**
	 * @功能：日志记录
	 * @参数：
	   @param  $param  Array()
	           $param['intype'] => 要记录日志的类型,
	           $param['txt']    => 返回结果集, 
	 * $args => 返回结果状态，0表示成功，非0表示失败
	 * $logger => 是否要记录日志
	 * @返回：若转换成功返回true,否则返回false或直接跳出
	 * 显示行号 __LINE__
	 */  
	function rewritetolog($param=array(), $args='', $logger =true) {
		
		
		//[entry]{}[/entry]
		 /*
		 $log['_id'] = '';//编号
		 $log['proj']  = '';//项目编号
		 $log['sid'] = '';//服务名字
		 $log['file'] = '';//采集的日志文件名
		 $log['iid'] = '';//实例号
		 $log['seq'] = '';//日志收集的序列号
		 $log['ts'] = '';//时间戳
		 $log['tsn'] = '';//时间戳的毫秒数字
		 $log['lv'] = '';//日志级别：TRACE,DEBUG等
		 $log['lvn'] = '';//日志级别的数字
		 $log['th'] = '';//线程名
		 $log['cl'] = '';//类名或文件名
		 $log['m'] = '';//方法名
		 $log['ln'] = '';//行号
		 $log['bsid'] = '';//业务会话id
		 $log['esid'] = '';//总线会话id
		 $log['txt'] = '';//日志内容
		 $log['ex'] = '';//异常Exception日志的堆栈信息
		 $log['ag'] = '';//user agent
		 $log['ip'] = '';//调用者ip
		 $log['uid'] = '';//用户id
		 */
		 
		 $log['proj'] = '';//项目编号
		 $log['sid']  = '';//服务名字
		 $log['file'] = '';//采集的日志文件名
		 $log['iid']  = '';//实例号
		 $log['seq']  = 0;//日志收集的序列号
		 $log['ts']   = '';//时间戳
		 $log['tsn']  = '';//时间戳的毫秒数字
		 $log['lv']   = 'ERROR';//日志级别：TRACE,DEBUG等
		 $log['lvn']  = 40000;//日志级别的数字
		 $log['th']   = '';//线程名
		 $log['cl']   = '';//类名或文件名
		 $log['m']    = '';//方法名
		 $log['ln']   = 0;//行号
		 $log['bsid'] = '';//业务会话id
		 $log['esid'] = '';//总线会话id
		 $log['txt']  = '';//日志内容
		 $log['ex']   = '';//异常Exception日志的堆栈信息
		 $log['ag']   = '';//user agent
		 $log['ip']   = '';//调用者ip
		 $log['uid']  = '';//用户id
		 
         $logStr = '';

		if($logger){
			$status = 'INFO';
			$flag = $this->_logflag;
			$curl = $this->_curl;
			if($flag){
				  if($args){
				   $status = 'ERROR';
				  }
				  	 $t['status']     = (string)$status;
					 $t['time']       = (string)date("Y-m-d H:i:s");
					 $t['name']       = $param['intype']?(string)$param['intype']:'';
					 $t['txt']        = $param['txt']?$param['txt']:'';
					 $t['curlUrl']    = $param['curlUrl']?(string)$param['curlUrl']:'';
					 $t['curlParam']  = $param['curlParam']?$param['curlParam']:'';
					 $t['curlInfo']   = $param['curlInfo']?(string)$param['curlInfo']:'';     //$curl->getInfo();
					 $t['curlStatus'] = $param['curlStatus']?(string)$param['curlStatus']:''; //$curl->getStatus();
					 $t['curlError']  = $param['curlError']?(string)$param['curlError']:'';   //$curl->getError();
					 $t['curlErrNo']  = $param['curlErrNo']?(string)$param['curlErrNo']:'';   //$curl->getErrNo();
				
		//处理第一条记录
		 $ts   = date('Y/m/d H:i:s',time());
		 $tsn  = (int)(time()*1000);
		 $log['proj']  = 'logcommand';//项目编号
		 $log['ts']    = $ts;//时间戳
		 $log['tsn']   = $tsn;//时间戳的毫秒数字
		 $level        = $this->getLoglevel($status);//日志级别
		 $log['lv']    = $level['lv'];//日志级别：TRACE,DEBUG等
		 $log['lvn']   = $level['lvn'];//日志级别的数字
		 $log['txt']   = $t;//日志内容
		 $log['ip']    = '';//调用者ip
		 
		 //$_SERVER
	              $logStr = json_encode($log);
				  $root = $this->_root;
				  $fileName  = $root.'/log/';
				  $fileName = $fileName.date('Y-m-d').".log";
				  $this->writeFile($fileName,$logStr,'a');
			}else{
			    if($args){
				   $status = '#Err#';
				//}
				  $log = $log.$intype.':'.date("Y-m-d H:i:s").":#txt#".$txt."#args#".$args."<br>\n";
				  $root = $this->_root;
				  $fileName  = $root.'/log/';
				  $fileName = $fileName.date('Y-m-d').".log";
				  $this->writeFile($fileName,$logStr,'a');
				}
			}
		}
	}
	
	     /*
    **
    * 日志级别
    * @param string $lv 日志级别字符串
    * @return int 返回数字
    */
    function getLoglevel($lv)
    {
		$lv = strtoupper($lv);
        $loglevel = array(
        'ERROR'=>'40000',//40000
        'WARN'=>'30000',//30000
        'INFO'=>'20000',//20000
        'DEBUG'=>'10000',//10000
        'TRACE'=>'5000',//5000
        );
		if($loglevel[$lv]){
			$level['lv'] = $lv;
			$level['lvn']= $loglevel[$lv];
		}else{
			$level['lv'] = 'ERROR';
			$level['lvn']= 40000;
		}
        return $level;
    }
}

/*

            $indexName  = ROOT.'/data/runtime.log';

            $log1 ='ajaxiid';
            $t[] = $url2;
            $t[] = $data;
            $t[] =  Yii::app()->curl->getInfo();
            $t[] =  Yii::app()->curl->getStatus();
            $t[] =  Yii::app()->curl->getError();
            $t[] =  Yii::app()->curl->getErrNo();
            $log1 .= json_encode($t);
            $log1 = $log1.'';
            $this->writeFile($indexName,$log1,'a');
			
*/

//执行程序脚本
$alllog = new AlllogCommand();
$alllog->run();

?>
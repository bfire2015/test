<?php
/**
 * **************************************************************************************
 * Description   : allconfig
 * Filename      : allconfig.php
 * Create time   : 2015-06-27
 * Last modified : 2015-06-27 
 * License       : MIT, GPL
 * update        : bfire.lai
 * **************************************************************************************
 */
 
 //文件名
 $monologDir   = '/var/www/to8to/syslog/api/monolog_'.date('Ymd').'.txt';
 $thriftlogDir = '/var/log/mobileapi/LOGV2_THRIFT_'.date('Ymd').'.log';
 $appphplogDir    = '/var/www/to8to/syslog/api/LOGV2_PHP_'.date('Ymd').'.log';
 $accesslogDir = '/var/log/mobileapi/LOGV2_ACCESS_'.date('Ymd').'.log';
 
 $phpfpmlogDir = '/var/www/to8to/syslog/www-error.log';//phpfpm
 $nginxlogDir  = '/var/www/to8to/syslog/to8to_error.log';//nginx
 //$yuyuecallDir = '/var/www/to8to/syslog/newcrmlog/yuyuecall.log';
 //$lunciyuyueDir = '/var/www/to8to/syslog/newcrmlog/lunci_'.date('Ymd').'.log';
 //$reqyuyueDir   = '/var/www/to8to/syslog/yuyuecall/'.date('Ymd').'.log';
 
 $yuyuecallDir = './data/yuyuecall.log';
 $lunciyuyueDir = './data/lunci_'.date('Ymd').'.log';
 $reqyuyueDir   = './data/'.date('Ymd').'.log';
 $vrayRenderDir   = './data/vrayRender_'.date('Ymd').'.log';
 
 //第次读取行数 默认100行
 $getNum  = 100;
 
//logtype1,json ,2,单行 3,多行
//monolog 日志
$log_Info[] = array('_dir'=>$monologDir,'_logtype'=>1,'_type'=>'app','_proj'=>'monolog','_iid'=>'','_getNum'=>$getNum);
//thriftlogDir 日志
$log_Info[] = array('_dir'=>$thriftlogDir,'_logtype'=>2,'_type'=>'app','_proj'=>'Thriftlog','_iid'=>'','_getNum'=>$getNum);
//appphplogDir 日志
$log_Info[] = array('_dir'=>$appphplogDir,'_logtype'=>3,'_type'=>'app','_proj'=>'Phplog','_iid'=>'','_getNum'=>$getNum);
//accesslog 日志
$log_Info[] = array('_dir'=>$accesslogDir,'_logtype'=>1,'_type'=>'app','_proj'=>'Accesslog','_iid'=>'','_getNum'=>$getNum);
//phpfpmlog 日志
$log_Info[] = array('_dir'=>$phpfpmlogDir,'_logtype'=>1,'_type'=>'phpfpm','_proj'=>'Phpfpm','_iid'=>'','_getNum'=>$getNum);
//nginxlog 日志
$log_Info[] = array('_dir'=>$nginxlogDir,'_logtype'=>1,'_type'=>'nginx','_proj'=>'Nginx','_iid'=>'','_getNum'=>$getNum);
//yuyuecall 日志
$log_Info[] = array('_dir'=>$yuyuecallDir,'_logtype'=>1,'_type'=>'yuyuecall','_proj'=>'yuyuecall','_iid'=>'','_getNum'=>$getNum);
//lunciyuyue 日志
$log_Info[] = array('_dir'=>$lunciyuyueDir,'_logtype'=>1,'_type'=>'yuyuecall','_proj'=>'lunciyuyue','_iid'=>'','_getNum'=>$getNum);
//reqyuyue 日志
$log_Info[] = array('_dir'=>$reqyuyueDir,'_logtype'=>1,'_type'=>'yuyuecall','_proj'=>'reqyuyue','_iid'=>'','_getNum'=>$getNum);
//vrayRender 日志
$log_Info[] = array('_dir'=>$vrayRenderDir,'_logtype'=>1,'_type'=>'vrayrender','_proj'=>'','_iid'=>'','_getNum'=>$getNum);


				
 //信息返回
return array(
    'params' => array(
        'es_Conn' => array(//配置ES连接服务
                '_index'=> 'log_test',
                'host'=>'192.168.1.95',//192.168.2.191
                'port'=>'9200',//39200
                ),
        'log_Info' => $log_Info,//LOG info
		'log_Flag' =>1,//log 是否开启打日志，默认为0，并且只记错误日志
      ),
);

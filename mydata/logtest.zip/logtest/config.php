<?php

/**
 * **************************************************************************************
 * Description   : config
 * Filename      : config.php
 * Create time   : 2015-03-25
 * Last modified : 2015-04-22 
 * License       : MIT, GPL
 * update        : bfire
 * **************************************************************************************
 */
 
 //网站根目录
  if (!defined('ROOT')) {                       
	define('ROOT', dirname(__FILE__));
	//目前root 只显示到 D:\wamp\www\test\
  }

 $monologDir   = '/var/www/to8to/syslog/api/monolog_'.date('Ymd').'.txt';
 $thriftlogDir = '/var/log/mobileapi/LOGV2_THRIFT_'.date('Ymd').'.log';
 $phplogDir    = '/var/www/to8to/syslog/api/LOGV2_PHP_'.date('Ymd').'.log';
 $accesslogDir = '/var/log/mobileapi/LOGV2_ACCESS_'.date('Ymd').'.log';
 
 $phpfpmlogDir = '/var/www/to8to/syslog/www-error.log';//phpfpm
 $nginxlogDir  = '/var/www/to8to/syslog/to8to_error.log';//nginx
 $yuyuecallDir = '/var/www/to8to/syslog/newcrmlog/yuyuecall.log';
 
 //$lunciyuyueDir = '/var/www/to8to/syslog/newcrmlog/lunci_'.date('Ymd').'.log';
 //$reqyuyueDir   = '/var/www/to8to/syslog/yuyuecall/'.date('Ymd').'.log';
 
 $lunciyuyueDir = './data/lunci_'.date('Ymd').'.log';
 $reqyuyueDir   = './data/'.date('Ymd').'.log';

return array(

    'params' => array(

        //配置ES连接服务
        'ES_conn' => array(
                '_index'=> 'log_test',
                '_type' => 'app',
                'host'=>'192.168.1.95',//192.168.2.191
                'port'=>'9200',//39200
                ),
		//LOG DIR
        'LOG_dir' => array(
                'monologDir'=> $monologDir,
                'thriftlogDir' => $thriftlogDir,
                'phplogDir'=>$phplogDir,//58.67.156.84
                'accesslogDir'=>$accesslogDir,
				'phpfpmlogDir'=>$phpfpmlogDir,//_type :phpfpm
				'nginxlogDir'=>$nginxlogDir,//_type   :nginx
				'yuyuecallDir'=>$yuyuecallDir,//_type :yuyuecall
				'lunciyuyueDir'=>$lunciyuyueDir,//_type :lunciyuyue
				'reqyuyueDir'=>$reqyuyueDir,//_type :reqyuyue
                ),
		//log 是否开启打日志，默认为0，并且只记错误日志
		'LOG_flag' =>1,
      ),
);
